# AplikasiPerizinan
Aplikasi Perizinan adalah aplikasi layanan masyarakat daerah kecamatan <b>Pulau Laut Utara</b>
yang akan melakukan pengurusan izin usaha jenis mikro
